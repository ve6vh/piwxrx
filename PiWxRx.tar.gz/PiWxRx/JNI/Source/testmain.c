// testMain.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// pertains to windows only
//
#ifdef _WIN32
#include <io.h>
#include <fcntl.h>
typedef __ptw32_handle_t pthread_t;
#define snooze(x) usleep(x/1000)
#else
#include <unistd.h>
#define snooze(x) sleep(x)
#endif

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

#include "rtl.h"

#define BUFFERSIZE 4096

// receiver state machine
#define	IDLE		0
#define	HDR			1
#define	TLR			2

char buffer[BUFFERSIZE];
char *cmdline = "rtlfm -M fm -f 162.4M -g 38 -";
char testcmd[500];
unsigned char header[] = { 0x80, 0x00, 0x37, 0xed, 0x02, 0x5d, 0xcb, 0x9b, 0x3f, 0x82, 0xEF, 0x87 };

struct background_t {
	int		rxstate;
	BOOL	run;
	BOOL	exit;
	char	*cmdline;
	pthread_t thread;
	int		debuglevel;
	void *(*background_func)(void *arg);
	void(*byte_rx_func)(DEMOD_BYTE x);
} background;

static void *background_thread_fn(void *arg);
static volatile int g_exit = FALSE;
static int tlrcnt;

#ifdef _WIN32
static BOOL WINAPI console_ctrl_handler(DWORD dwCtrlType)
{
	background.exit = TRUE;
	return TRUE;
}
#endif

void byteRx(DEMOD_BYTE byterx)
{
	// add a small fsm in here to look for AB, then "+", then three "-"
	// resync at the end.

	fprintf(stdout, "%c", byterx);

	switch (background.rxstate) {

	case IDLE:
		if (byterx == 0xAB) {
			background.rxstate = HDR;
		}
		break;

	case HDR:
		if (byterx == '+') {
			tlrcnt = 0;
			background.rxstate = TLR;
		}
		break;

	case TLR:
		if (byterx == '-') {
			tlrcnt++;
			if (tlrcnt == 3) {
				background.rxstate = IDLE;
				ClrFSKSync();
				fprintf(stdout, "\n");
			}
			if (byterx == 0x00) {
				background.rxstate = IDLE;
				ClrFSKSync();
				fprintf(stdout, "\n");
			}
		}
		break;
	}

}

int main(int argc, char *argv[])
{
	unsigned char *hdrptr = &header[0];
	char *remoteip = (char *) "/192.168.1.23";
	char *myip = (char *)"/192.168.1.70";
	int codecmode = CODEC_PCMU;
	BOOL runudp = TRUE;

	// setup the defaults
	background.background_func = &background_thread_fn;
	background.cmdline = cmdline;
	background.byte_rx_func = &byteRx;
	background.debuglevel = 0;
	background.exit = FALSE;
	background.run = FALSE;
	background.rxstate = IDLE;

	for(int i=1;i<argc;i++)
	  if(argv[i][0] == '-')
		switch (argv[i][1]) {

		case 'c':
			codecmode = CODEC_NONE;
		break;

		case 'n':
			runudp = FALSE;
			break;

		case 'f':
			background.cmdline = testcmd;
			sprintf(testcmd, "./filereader -l -f %s ", argv[++i]);
			break;

		case 'd':
			switch (argv[i][2]) {

			case 'd':
				background.debuglevel |= DEBUG_MSGS;
				break;

			case 'o':
				background.debuglevel |= DEBUG_OSC;
				break;

			case 'l':
				background.debuglevel |= DEBUG_LPF;
				break;

			case 'm':
				background.debuglevel |= DEBUG_DEMOD;
				break;

			case 'u':
				background.debuglevel |= DEBUG_UDP;
				break;

			case 'w':
				background.debuglevel |= DEBUG_WRITE;
				break;

			case 'b':
				background.debuglevel |= DEBUG_BITSHIFT;
				break;

			case 'B':
				background.debuglevel |= DEBUG_BYTEOUT;
				break;
			}
			break;

		default:
			fprintf(stderr, "TestMain -f <file> -c -n -d[dolmuwbB]\n");
			exit(100);
		}

	printf("Starting background thread\n");

	background.run = TRUE;
	pthread_create(&background.thread, NULL, background.background_func, (void *)(&background));
	snooze(100);

	if (runudp) {
		if (!StartUDP(hdrptr, 12, remoteip, 12567, myip, 12789, codecmode, 0))	{
			DEBUGPRINTF("StartUDP failed\n");
			exit(100);
		}
	}

	if(runudp)
		StopUDP();

	pthread_join(background.thread, NULL);

	StopRTL();

	return(0);
}

//start the process
static void *background_thread_fn(void *arg)
{
	struct background_t *s = arg;

	if (!InitRTL(s->cmdline, s->byte_rx_func, s->debuglevel))	{
		DEBUGPRINTF("Init failed: background exiting\n");
		return NULL;
	}


	SetDebugLevel(s->debuglevel);

	while (!(s->run));
	RunRTL();

	while (!(s->exit));

	return NULL;
}
